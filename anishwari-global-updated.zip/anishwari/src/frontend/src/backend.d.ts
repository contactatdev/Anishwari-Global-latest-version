import type { Principal } from "@icp-sdk/core/principal";
export interface Some<T> {
    __kind__: "Some";
    value: T;
}
export interface None {
    __kind__: "None";
}
export type Option<T> = Some<T> | None;
export interface Inquiry {
    name: string;
    email: string;
    company: string;
    message: string;
    productInterest: ProductCategory;
}
export interface Product {
    id: bigint;
    name: string;
    origin: string;
    unit: string;
    description: string;
    category: ProductCategory;
}
export enum ProductCategory {
    riceAndGrains = "riceAndGrains",
    oilseeds = "oilseeds",
    pulsesAndLegumes = "pulsesAndLegumes",
    fruitsAndVegetables = "fruitsAndVegetables",
    spices = "spices"
}
export interface backendInterface {
    addProduct(name: string, category: ProductCategory, description: string, origin: string, unit: string): Promise<bigint>;
    deleteProduct(id: bigint): Promise<void>;
    getInquiries(): Promise<Array<Inquiry>>;
    getProducts(): Promise<Array<Product>>;
    init(): Promise<void>;
    submitInquiry(name: string, email: string, company: string, productInterest: ProductCategory, message: string): Promise<void>;
    updateProduct(id: bigint, name: string, category: ProductCategory, description: string, origin: string, unit: string): Promise<void>;
}
